/* Write a Java program to execute the following statements. Observe and analyze the outputs
    a. boolean x =true; b. boolean x =true;
    int y = x;             int y =(int)x; 
*/

package Lab_2;

public class Execute_additional_b {
    public static void main(String[] args) {
        boolean x = true;
        int y = (int) x;
        System.out.println(y);
    }
}
