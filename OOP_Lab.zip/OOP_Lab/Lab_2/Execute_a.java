/* Write a Java program to execute the following statements. Observe and analyze the outputs. */

package Lab_2;

public class Execute_a {
  public static void main(String[] args) {
    int x = 10;
    double y = x;
    System.out.println(y);
  }
}
