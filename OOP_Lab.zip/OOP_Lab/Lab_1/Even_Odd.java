
public class Even_Odd {
    public static void main(String[] args) {
        System.out.println("\n>> Program to check whether the number specified is Even or Odd:\n");
        int n = 15;
        if (n % 2 == 0) {
            System.out.println("-- The number " + n + " is Even.");
        } else {
            System.out.println("-- The number " + n + " is Odd.");
        }
    }
}
